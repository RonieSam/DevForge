package com.spring.devforge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevforgeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevforgeApplication.class, args);
	}

}
