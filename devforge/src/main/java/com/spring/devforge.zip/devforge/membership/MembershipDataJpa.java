package com.spring.devforge.membership;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MembershipDataJpa extends JpaRepository<Membership,Integer> {
	public boolean existsByRoleAndOrgId(Role role,int orgId);
	public Membership findByUserIdAndOrgId(int userId,int orgId);
	public void deleteAllByOrgId(int orgId);
}
