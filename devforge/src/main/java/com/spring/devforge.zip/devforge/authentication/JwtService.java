package com.spring.devforge.authentication;

import java.util.Date;

import javax.crypto.SecretKey;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;



@Service
public class JwtService{

	private final static SecretKey key=Keys.hmacShaKeyFor("Hello my name is Ronie Samuel this is my first project".getBytes());
	
	public String generateJwt(String email) {
		
		return Jwts.builder()
				.subject(email)
				.signWith(key)
				.issuedAt(new Date())
				.expiration(new Date(System.currentTimeMillis()+60*1000*60))
				.compact();
	}
	
	public String extractEmail(String token) {
		return Jwts.parser()
				.verifyWith(key)
				.build()
				.parseSignedClaims(token)
				.getPayload()
				.getSubject();
	}
	
	public boolean validateToken(String token,UserDetails userDetails) {
		String email=extractEmail(token);
		if(email.equals(userDetails.getUsername())&&!isTokenExpired(token)) {
			return true;
		}
		return false;
		
	}
	
	public boolean isTokenExpired(String token) {
		Date ex= Jwts.parser().verifyWith(key).build().parseSignedClaims(token).getPayload().getExpiration();
		return new Date().after(ex);
		
	}

}



