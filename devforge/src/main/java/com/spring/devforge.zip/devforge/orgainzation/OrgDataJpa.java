package com.spring.devforge.orgainzation;

import org.springframework.data.jpa.repository.JpaRepository;


public interface OrgDataJpa extends JpaRepository<Organization, Integer> {
	
	public boolean existsBySlug(String slug);
//	public Organization findBySlugAndOwnerId(String slug,int ownerId);
	public Organization findBySlug(String slug);


}
