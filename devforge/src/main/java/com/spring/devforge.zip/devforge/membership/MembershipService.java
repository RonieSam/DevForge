package com.spring.devforge.membership;

import java.nio.file.AccessDeniedException;

import org.apache.coyote.BadRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.spring.devforge.authentication.UserDataJpa;
import com.spring.devforge.authentication.Users;
import com.spring.devforge.orgainzation.OrgDataJpa;
import com.spring.devforge.orgainzation.Organization;

import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.ConstraintViolationException;

@Service
public class MembershipService {
	

	
	@Autowired
	MembershipDataJpa repo;
	
	@Autowired
	UserDataJpa userRepo;
	
	@Autowired
	OrgDataJpa orgRepo;
	
	public void handleOwnerCreation(Organization org,Users owner) {
		repo.save(new Membership(owner,org,Role.OWNER));
	}
	
	public boolean checkAccess(Role requester,Role user) {
		if(requester==null||requester==Role.USER||(requester==Role.ADMIN&&(user==Role.OWNER||user==Role.ADMIN))) return true;
		else return false;
		
	}
	
	public void handleMembershipCreation(String slug,String username,Role role) throws AccessDeniedException {
		
		Users user=userRepo.findByUsername(username);
		Organization org=orgRepo.findBySlug(slug);
		if(user==null||org==null)throw new EntityNotFoundException("The user or the organization is invalid");
		if(repo.findByUserIdAndOrgId(user.getId(), org.getId())!=null)throw new IllegalArgumentException("The user is already part of the organization");
		Authentication auth=SecurityContextHolder.getContext().getAuthentication();
		String email=auth.getName();
		Users requester=userRepo.findByEmail(email);
		Membership reqMembership=repo.findByUserIdAndOrgId(requester.getId(), org.getId());
		if(checkAccess(reqMembership.getRole(),role)) {
			throw new AccessDeniedException("Requesting user doesnt have enough authority");
		}
		if(reqMembership.getRole()==Role.OWNER&&role==Role.OWNER) {
			reqMembership.setRole(Role.ADMIN);
			repo.save(reqMembership);
			org.setOwner(user);
		}
		
		Membership newMembership=new Membership(user,org,role);
		repo.save(newMembership);
		
		
	}
	public void handleMembershipUpdation(String slug,String username,Role role) throws EntityNotFoundException, AccessDeniedException{
		Users user=userRepo.findByUsername(username);
		Organization org=orgRepo.findBySlug(slug);
		if(user==null||org==null)throw new EntityNotFoundException("The user or the organization is invalid");
		Authentication auth=SecurityContextHolder.getContext().getAuthentication();
		String email=auth.getName();
		Users requester=userRepo.findByEmail(email);
		Membership reqMembership=repo.findByUserIdAndOrgId(requester.getId(), org.getId());
		if(checkAccess(reqMembership.getRole(),role)) {
			throw new AccessDeniedException("Requesting user doesnt have enough authority");
		}
		if(reqMembership.getRole()==Role.OWNER&&role==Role.OWNER) {
			reqMembership.setRole(Role.ADMIN);
			repo.save(reqMembership);
			org.setOwner(user);

		}
		Membership membership=repo.findByUserIdAndOrgId(user.getId(), org.getId());
		if(membership==null)throw new EntityNotFoundException("User is not part of the organization");
		membership.setRole(role);
		repo.save(membership);
	}
	
	public void handleMembershipDeletion(String slug,String username) throws AccessDeniedException,EntityNotFoundException{
		Users user=userRepo.findByUsername(username);
		Organization org=orgRepo.findBySlug(slug);
		if(user==null||org==null)throw new EntityNotFoundException("This request cannot be processed");
		Authentication auth=SecurityContextHolder.getContext().getAuthentication();
		String email=auth.getName();
		Users requester=userRepo.findByEmail(email);
		Membership reqMembership=repo.findByUserIdAndOrgId(requester.getId(), org.getId());
		Membership membership=repo.findByUserIdAndOrgId(user.getId(), org.getId());
		if(membership==null)throw new EntityNotFoundException("User is already not part of the organization");
		if(membership.getRole()==Role.OWNER) throw new AccessDeniedException("Owner membership cannot be deleted without transferring ownership");
		if(checkAccess(reqMembership.getRole(),membership.getRole())) {
			throw new AccessDeniedException("Requesting user doesnt have enough authority");
		}
		repo.deleteById(membership.getId());
	}
	
	
	
	
	
}
