package com.spring.devforge.requests;

import java.nio.file.AccessDeniedException;
import java.util.List;


import org.apache.coyote.BadRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.devforge.ApiResponse;

@RestController
public class RequestController {
	
	@Autowired
	RequestService service;
	

	@PostMapping("/request")
	public ResponseEntity<ApiResponse> createRequest(@RequestBody RequestDto req) throws AccessDeniedException{
		RequestData data=service.handleRequestCreation(req.getSlug(),req.getMsg());
		return new ResponseEntity<>(new ApiResponse(true,"Request has been sent",data),HttpStatus.CREATED);
	}
	
	@GetMapping("/org/{orgId}/request")
	public ResponseEntity<ApiResponse> getAllRequest(@PathVariable long orgId ) throws  AccessDeniedException {
		List<RequestData> data=service.handleGetAllRequests(orgId);
		return new ResponseEntity<>(new ApiResponse(true,"",data),HttpStatus.OK);
	}
	
	@PostMapping("request/{id}")
	public ResponseEntity<ApiResponse> reviewRequest(@PathVariable long id,@RequestBody RequestReviewDto r ) throws AccessDeniedException, BadRequestException {
		RequestData data=service.handleReviewRequest(id, r.getStatus());
		return new ResponseEntity<>(new ApiResponse(true,"Request has been reviewed",data),HttpStatus.OK);
	}
//	@DeleteMapping("/org/{slug}/request/{id}")
//	public ResponseEntity<ApiResponse> deleteRequest(@PathVariable String slug,@PathVariable long id,@RequestBody RequestReviewDto r ) throws AccessDeniedException, BadRequestException {
//		service.handleDeleteRequest(id,slug);
//		return new ResponseEntity<>(new ApiResponse(true,"Request has been deleted",null),HttpStatus.OK);
//	}
}
