import { apiClient } from "./apiClient";


export async function getOrgUserTasks(org){
    try{
        const res=await apiClient.get(`/tasks/me`,{params:{orgId:org.id}})
        return res.data.data
    }
    catch(e){
        console.log(e.message)
        throw e;
    }
}
export async function getUserTasks(){
    try{
        const res=await apiClient.get(`/tasks/me`)
        return res.data.data
    }
    catch(e){
        console.log(e.message)
        throw e;
    }
}

export async function createTask(task){
    try{
        
        await apiClient.post(`projects/${task.project}/tasks`,task)
    }
    catch(e){
        console.log(e);
        throw(e);
    }
}

export async function updateTask(task){
    try{

        await apiClient.put(`tasks/${task.id}`,task)
    }
    catch(e){
        console.log(e);
        throw(e);
    }
}
export async function deleteTask(id){
    try{
        await apiClient.delete(`tasks/${id}`,null)
    }
    catch(e){
        console.log(e);
        throw(e);
    }
}

